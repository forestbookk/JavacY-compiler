package backend;

public interface MipsNode {
}
