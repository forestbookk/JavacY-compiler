package frontend.symbol.symbols.Array;

import utils.ParamType;

public interface Array {
    public ParamType getParamType();
}
