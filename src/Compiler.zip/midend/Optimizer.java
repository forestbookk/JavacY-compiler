package midend;

import llvm_ir.component.Module;
import utils.ArgType;
import utils.Printer;

import java.io.IOException;

public class Optimizer {
    public static Module irModule;

    public static void run() throws IOException {
        RemoveDeadCode.removeExtraBr();
        RemoveDeadCode.removeUnreachableBB();
        Printer.solve(ArgType.LLVM);
        CFGBuilder.run();

        Mem2Reg.run();
        LiveVarAnalysis.run();
        new RegAllocator().performRegAllocation();

        Printer.solve(ArgType.LLVM);
        RemovePhi.run();

        Printer.solve(ArgType.LLVM);
    }
}
