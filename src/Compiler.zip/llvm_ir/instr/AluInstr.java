package llvm_ir.instr;

import backend.MipsBuilder;
import backend.Register;
import backend.instruction.i_instr.AluImi;
import backend.instruction.r_instr.AluRmi;
import backend.instruction.r_instr.HiLoRmi;
import backend.instruction.r_instr.MuDiRmi;
import llvm_ir.Value;
import llvm_ir.component.Constant;
import llvm_ir.component.Instruction;
import llvm_ir.component.UndefinedValue;
import llvm_ir.component.type.LLVMType;

import java.util.Objects;

public class AluInstr extends Instruction {
    public enum AluOp {
        ADD, SUB, MUL, SDIV, SREM
    }

    private AluOp aluOp;

    public AluInstr(String name, LLVMType type, AluOp aluOp, Value op1, Value op2) {
        super(name, type);
        this.aluOp = aluOp;
        addOperand(op1);
        addOperand(op2);
    }

    @Override
    public String toString() {
        return name + " = " + aluOp.toString().toLowerCase() + " " +
                type.toString() + " " + getOp1().getName() + ", " + getOp2().getName();
    }

    public void toIType(Register rs, Integer imm, Register rd) {
        switch (aluOp) {
            case ADD -> {
                MipsBuilder.genNInsAluImi(AluImi.Op.addiu, rs, rd, imm);
            }
            case SUB -> {
                MipsBuilder.genNInsAluImi(AluImi.Op.subiu, rs, rd, imm);
            }
            default -> {
                throw new RuntimeException("Wrong AluOp Into IType");
            }
        }
    }

    public void toRType(Value rsValue, Register rs, Value rtValue, Register rt, Register rd) {
        // 处理 op1
        // 若op1为常数：则直接存入reg1
        if (rsValue instanceof Constant) {
            MipsBuilder.genNInsLiImi(rs, ((Constant) rsValue).getContent());
        } else if (rsValue instanceof UndefinedValue) {
            MipsBuilder.genNInsLiImi(rs, 0);
        }
        // 若op1 非常数：
        else {
            rs = MipsBuilder.allocateOrLoadRegForValue(rsValue, rs, true);
        }

        // 处理 op2
        // 若op2为常数：则直接存入reg2
        if (rtValue instanceof Constant) {
            MipsBuilder.genNInsLiImi(rt, ((Constant) rtValue).getContent());
        } else if (rtValue instanceof UndefinedValue) {
            MipsBuilder.genNInsLiImi(rt, 0);
        }
        // 若op2 非常数：
        else {
            rt = MipsBuilder.allocateOrLoadRegForValue(rtValue, rt, true);
        }

        // 处理计算逻辑
        switch (aluOp) {
            case ADD -> {
                MipsBuilder.genNInsAluRmi(AluRmi.Op.addu, rs, rt, rd, null);
            }
            case SUB -> {
                MipsBuilder.genNInsAluRmi(AluRmi.Op.subu, rs, rt, rd, null);
            }
            case MUL -> {
                MipsBuilder.genNInsMuDiRmi(MuDiRmi.Op.mult, rs, rt);
                MipsBuilder.genNInsHiLoRmi(HiLoRmi.Op.mflo, rd);
            }
            case SDIV -> {
                MipsBuilder.genNInsMuDiRmi(MuDiRmi.Op.div, rs, rt);
                MipsBuilder.genNInsHiLoRmi(HiLoRmi.Op.mflo, rd);
            }
            case SREM -> {
                MipsBuilder.genNInsMuDiRmi(MuDiRmi.Op.div, rs, rt);
                MipsBuilder.genNInsHiLoRmi(HiLoRmi.Op.mfhi, rd);
            }
        }
    }

    @Override
    public void toAssembly() {
        super.toAssembly();
        Value op1 = getOp1();
        Value op2 = getOp2();
        final boolean isOp1Imm = op1.isImm();
        final boolean isOp2Imm = op2.isImm();
        Register reg1 = Register.K0;
        Register reg2 = Register.K1;
        Register rd = Objects.requireNonNullElse(
                MipsBuilder.getRegisterForValue(this), Register.K0);

        // calc_i 处理
        if ((aluOp == AluOp.ADD || aluOp == AluOp.SUB) && isOp2Imm) {
            // 若op1是常数
            if (op1 instanceof Constant) {
                // 将op1存进寄存器
                MipsBuilder.genNInsLiImi(reg1, ((Constant) op1).getContent());
            } else if (op1 instanceof UndefinedValue) {
                MipsBuilder.genNInsLiImi(reg1, 0);
            } else {
                reg1 = MipsBuilder.allocateOrLoadRegForValue(op1, reg1, true);
            }
            // 现在 op1 一定是寄存器形式
            toIType(reg1, ((Constant) op2).getContent(), rd);
        } else if (aluOp == AluOp.ADD && isOp1Imm && !isOp2Imm) {
            if (op2 instanceof Constant) {
                MipsBuilder.genNInsLiImi(reg2, ((Constant) op2).getContent());
            } else if (op2 instanceof UndefinedValue) {
                MipsBuilder.genNInsLiImi(reg2, 0);
            } else {
                reg2 = MipsBuilder.allocateOrLoadRegForValue(op2, reg2, true);
            }
            toIType(reg2, ((Constant) op1).getContent(), rd);
        }
        // calc_r 处理（此时 op1 和 op2 仍然有可能是立即数）
        else {
            toRType(op1, reg1, op2, reg2, rd);
        }

        // 处理rd
        if (MipsBuilder.getRegisterForValue(this) == null) {
            MipsBuilder.storeRegValueToStack(this, rd, true);
        }
    }

    @Override
    public boolean canBeUsed() {
        return true;
    }
}
