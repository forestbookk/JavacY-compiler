package llvm_ir;

public class Error extends Value{
    public Error() {
        super(null, null);
    }
}
