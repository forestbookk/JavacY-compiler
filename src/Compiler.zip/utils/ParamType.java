package utils;

public enum ParamType {
    VAR, INT_ARRAY, CHAR_ARRAY
}
