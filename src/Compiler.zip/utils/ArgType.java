package utils;

public enum ArgType {
    LEXER, PARSER, SYMBOL, LLVM, MIPS, OPTIMIZE
}
